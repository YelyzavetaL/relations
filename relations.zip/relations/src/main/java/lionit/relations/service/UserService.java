package lionit.relations.service;

import lionit.relations.models.User;
import org.springframework.security.core.userdetails.UserDetails;

public interface UserService extends UserDetails {
    void save(User user);
}
