package lionit.relations.config;

public class WebConfig {
}
