package lionit.relations.models;


public enum Role {
    ROLE_USER, ROLE_ADMIN, ROLE_TEACHER
}
